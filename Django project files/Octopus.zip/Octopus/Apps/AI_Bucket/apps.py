from django.apps import AppConfig
from transformers import AutoTokenizer
import tensorflow as tf
import smart_open
import boto3


class AiBucketConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Apps.AI_Bucket'

    tokenizer = AutoTokenizer.from_pretrained('src/NLP/SSS/tokenizer/')
    session = boto3.Session(
        aws_access_key_id='AKIARCX7LRA5XXYPI2TM',
        aws_secret_access_key='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')
    file = smart_open.open('s3://ocopus-src/src/NLP/SSS/SSS_model.tflite', mode='rb',
                           transport_params={'client': session.client('s3')})
    m = file.read()
    file.close()
    interpreter = tf.lite.Interpreter(model_content=m)
    del m
    del session
    del file
    model = interpreter.get_signature_runner()
