from django.shortcuts import render
from .Prediction import *
from rest_framework.views import APIView
from django.http import HttpResponse, JsonResponse
from .apps import AiBucketConfig
# Create your views here.
class call_model(APIView):

    def get(self, request):
        if request.method == 'GET':
            # sentence is the query we want to get the prediction for
            params = request.GET.get('sentence')

            # predict method used to get the prediction
            response = NLP_SSS_model(params, AiBucketConfig.model, AiBucketConfig.tokenizer)

            # returning JSON response
            return JsonResponse(response)

