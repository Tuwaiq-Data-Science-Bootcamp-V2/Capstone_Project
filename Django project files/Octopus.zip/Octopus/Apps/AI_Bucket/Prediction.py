import numpy as np

def NLP_SSS_model(text,model,tokenizer):
  tokens = tokenizer(text,truncation=True, padding='max_length',max_length=256,return_tensors='tf')

  preds = model(input_ids=tokens['input_ids'],attention_mask=tokens['attention_mask'])['concatenate'].flatten()
  sentiments_e = {0:'Positive',1:'Natural',2:'Negative'}
  speech_ace_e = {0:'Expression',1:'Assertion'}
  sarcasm_e = {0:'non-sarcastic',1:'sarcastic'}
  thres_1 = 0.664
  thres_2 = 0.5
  sen = np.argmax(preds[:3])
  sa = (preds[3] >= thres_1).astype('int32')
  sar = (preds[4] >= thres_2).astype('int32')

  sa_cof = (1-preds[3],preds[3])
  sar_conf = (1-preds[4],preds[4])

  res = {'sentiment': sentiments_e[sen],'sentiment_conf':round(preds[sen]*100),'speech_act':speech_ace_e[sa],'speech_act_conf':round(sa_cof[sa]*100),'sarcasm':sarcasm_e[sar],'sarcasm_conf':round(sar_conf[sar]*100)}
  return res